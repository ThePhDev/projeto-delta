
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { DeltaMascot } from "@/components/delta-mascot";
import { QuestionCard, type QuestionData } from "@/components/question-card";

type DiagnosticQuestion = QuestionData & { axis: string; solution: string };

export default function DiagnosticPage() {
  const router = useRouter();
  const [questions, setQuestions] = useState<DiagnosticQuestion[]>([]);
  const [idx, setIdx] = useState(0);
  const [results, setResults] = useState<{ axis: string; correct: boolean }[]>([]);
  const [phase, setPhase] = useState<"intro" | "running" | "done">("intro");

  useEffect(() => {
    fetch("/api/diagnostic")
      .then((r) => r.json())
      .then((d) => setQuestions(d.questions));
  }, []);

  const current = questions[idx];

  if (phase === "intro") {
    return (
      <div className="flex min-h-svh flex-col items-center justify-center px-6 text-center">
        <DeltaMascot pose="cientista" size={180} priority />
        <h1 className="mt-6 font-display text-3xl font-bold">Diagnóstico Inicial</h1>
        <p className="mt-2 max-w-md text-zinc-500">
          10 questões pra descobrir seus pontos fortes e fracos. Não conta XP nem vidas - é só pra te conhecer.
        </p>
        <button onClick={() => setPhase("running")} className="btn-primary mt-8">
          Vamos lá →
        </button>
      </div>
    );
  }

  if (phase === "done") {
    const axisAcc = new Map<string, { ok: number; total: number }>();
    for (const r of results) {
      const cur = axisAcc.get(r.axis) ?? { ok: 0, total: 0 };
      cur.total += 1;
      if (r.correct) cur.ok += 1;
      axisAcc.set(r.axis, cur);
    }
    const correctCount = results.filter((r) => r.correct).length;

    return (
      <div className="flex min-h-svh flex-col items-center px-6 py-10 text-center">
        <DeltaMascot pose={correctCount >= 7 ? "comemorando" : "feliz"} size={180} priority />
        <h1 className="mt-6 font-display text-3xl font-bold">Tudo mapeado!</h1>
        <p className="mt-2 text-zinc-500">
          Você acertou {correctCount} de 10. Aqui vão seus pontos pra trabalhar:
        </p>

        <div className="mt-8 w-full max-w-md space-y-2 text-left">
          {Array.from(axisAcc.entries()).map(([axis, { ok, total }]) => {
            const pct = Math.round((ok / total) * 100);
            return (
              <div key={axis} className="card-soft py-3">
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium">{axis}</span>
                  <span className="text-zinc-500">{ok}/{total} · {pct}%</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-zinc-100">
                  <div
                    className={`h-full rounded-full ${pct >= 70 ? "bg-emerald-500" : pct >= 40 ? "bg-amber-400" : "bg-orange-500"}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <button onClick={() => router.push("/home")} className="btn-primary mt-8">
          Começar a trilha →
        </button>
      </div>
    );
  }

  if (!current) {
    return (
      <div className="flex min-h-svh items-center justify-center">
        <div className="text-zinc-500">Carregando questões...</div>
      </div>
    );
  }

  return (
    <div className="min-h-svh px-4 py-4">
      <div className="mx-auto flex max-w-2xl items-center gap-3">
        <span className="text-zinc-500">📋 Diagnóstico</span>
        <div className="flex-1">
          <div className="h-2 w-full overflow-hidden rounded-full bg-zinc-100">
            <div
              className="h-full bg-delta-turquoise transition-all"
              style={{ width: `${((idx + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>
        <span className="text-xs text-zinc-500">
          {idx + 1}/{questions.length}
        </span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="mt-4"
        >
          <QuestionCard
            question={current}
            meta={`${current.axis} · ${current.difficulty}`}
            onAnswer={(_, isCorrect) => {
              setResults((prev) => [...prev, { axis: current.axis, correct: isCorrect }]);
              if (idx + 1 >= questions.length) setPhase("done");
              else setIdx((i) => i + 1);
            }}
          />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
