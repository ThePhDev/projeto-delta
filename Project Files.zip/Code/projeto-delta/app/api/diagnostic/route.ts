
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { AXES } from "@/lib/axes";

/**
 * Retorna 10 questões diagnósticas - uma por eixo dos 10 primeiros, dificuldade easy/medium.
 * Embaralhadas para que o usuário não veja sempre na mesma ordem.
 */
export async function GET() {
  const targetAxes = AXES.slice(0, 10).map((a) => a.slug);

  const picks = await Promise.all(
    targetAxes.map(async (axis) => {
      const candidates = await prisma.question.findMany({
        where: { axis, difficulty: { in: ["easy", "medium"] } },
        take: 20
      });
      if (candidates.length === 0) return null;
      return candidates[Math.floor(Math.random() * candidates.length)];
    })
  );

  const questions = picks
    .filter((q): q is NonNullable<typeof q> => q !== null)
    .map((q) => ({
      id: q.id,
      axis: AXES.find((a) => a.slug === q.axis)?.name ?? q.axis,
      statement: q.statement,
      options: q.options as string[],
      correctIdx: q.correctIdx,
      difficulty: q.difficulty,
      solution: q.solution
    }));

  // Shuffle final order
  questions.sort(() => Math.random() - 0.5);

  return NextResponse.json({ questions });
}
