<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'self' app:;
                   script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://www.googletagmanager.com https://googleads.g.doubleclick.net https://connect.facebook.net https://analytics.tiktok.com https://fpnpmcdn.net https://fpjscdn.net;
                   style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
                   style-src-elem 'self' 'unsafe-inline' https://fonts.googleapis.com;
                   font-src 'self' data: https://fonts.gstatic.com;
                   img-src 'self' app: blob: data: local-media: https: http:;
                   connect-src 'self' app: blob: local-media: https://flikai.com wss://flikai.com https://*.flikai.com wss://*.flikai.com https://api.flik.ai wss://api.flik.ai https://*.onrender.com wss://*.onrender.com https://*.auth0.com https://*.stripe.com https://storage.googleapis.com https://*.googleapis.com https://*.fal.media https://unpkg.com https://www.google-analytics.com https://www.googleadservices.com https://googleads.g.doubleclick.net https://*.facebook.com https://*.facebook.net https://*.tiktok.com https://analytics.tiktok.com https://*.posthog.com https://us.i.posthog.com https://api.fpjs.io https://*.api.fpjs.io http://localhost:* ws://localhost:* wss://localhost:*;
                   frame-src https://*.stripe.com https://*.auth0.com https://td.doubleclick.net;
                   worker-src 'self' blob:;
                   media-src 'self' app: blob: data: local-media: https: http:">
  <!-- Legacy "shortcut icon" attribute required by Google's OAuth App
       Verification heuristic. Per the top-voted Stack Overflow answer on
       brand-verification failures, Google's automated verifier looks for
       this exact `rel="shortcut icon"` value and compares its byte hash
       against the App logo uploaded on the OAuth Branding page. If the
       bytes differ, verification silently fails with flags like "app name
       on home page does not match OAuth consent screen" or "home page
       does not explain the purpose of your app". Upload the exact file
       apps/web/public/flik_favicon.png to the OAuth Branding form so
       Google stores the identical bytes this link serves. -->
  <link rel="shortcut icon" type="image/png" href="/flik_favicon.png" />
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="/favicon-48x48.png" />
  <link rel="icon" type="image/png" href="/flik_favicon.png" />
  <link rel="apple-touch-icon" href="/favicon-256x256.png" />
  <link rel="manifest" href="/site.webmanifest" />
  <meta name="theme-color" content="#212121" media="(prefers-color-scheme: dark)" />
  <meta name="theme-color" content="#F5F3F0" media="(prefers-color-scheme: light)" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-title" content="Flik AI" />
  <meta name="application-name" content="Flik AI" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <title>Flik AI</title>
  <meta
    name="description"
    content="Flik AI is a creative agent that turns your ideas into videos, images, and audio — all from a single workspace that plans, generates, and iterates for you."
  />
  <link rel="canonical" href="https://www.flikai.com/" />
  <meta name="robots" content="index, follow" />
  <!--
    Search-engine webmaster verification.
    Uncomment a line and paste the real token from each console once claimed.
    We intentionally only ship the two engines that matter for US/EU traffic —
    DuckDuckGo, Brave, Kagi, and Ecosia all source from Bing, so claiming Bing
    also covers them. AI crawlers (GPTBot, ClaudeBot, PerplexityBot, etc.) have
    no consoles — they're handled via robots.txt + llms.txt.

      Google Search Console — https://search.google.com/search-console
      <meta name="google-site-verification" content="PASTE_TOKEN" />

      Bing Webmaster Tools — https://www.bing.com/webmasters
      (Bing supports one-click import from Google Search Console.)
      <meta name="msvalidate.01" content="PASTE_TOKEN" />

    IndexNow key is served at /indexnow.txt and referenced in robots.txt;
    generate it from Bing Webmaster Tools → Settings → API Access → Generate.
  -->
  <meta property="og:title" content="Flik AI" />
  <meta
    property="og:description"
    content="Flik AI is a creative agent that turns your ideas into videos, images, and audio — all from a single workspace that plans, generates, and iterates for you."
  />
  <meta property="og:url" content="https://www.flikai.com/" />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://www.flikai.com/flik_slash.png" />
  <meta property="og:image:alt" content="Flik AI logo" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="Flik AI" />
  <meta
    name="twitter:description"
    content="Flik AI is a creative agent that turns your ideas into videos, images, and audio — all from a single workspace that plans, generates, and iterates for you."
  />
  <meta name="twitter:image" content="https://www.flikai.com/flik_slash.png" />
  <meta name="twitter:image:alt" content="Flik AI logo" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <script type="module" crossorigin src="/assets/index-BJWsHit7.js"></script>
  <link rel="stylesheet" crossorigin href="/assets/index-Cdp_mHJY.css">
</head>

<body>
  <div id="root"></div>
  <!-- <noscript> block below is served to every visitor whose UA does NOT
       match our bot map in nginx.conf (i.e. real browsers get Vite's plain
       shell, where this noscript is the primary text content in the
       initial HTML body). Google's OAuth Trust & Safety verifier uses
       a user agent that falls outside our bot-map regex, so this is what
       it reads when it crawls https://www.flikai.com/.
       
       Requirements this block must satisfy to pass OAuth verification:
       (a) H1 text must match the OAuth consent screen "App name" EXACTLY
           (character-for-character: "Flik AI") — otherwise Trust & Safety
           flags "app name on home page does not match OAuth consent screen".
       (b) Body must explain what the app does AND how it uses Google user
           data requested by the OAuth scopes (openid, profile, email) —
           otherwise flagged "home page does not explain the purpose of
           your app". Use plain verb-driven language Google's AI verifier
           recognizes (avoid abstract phrases like "creative agent that
           turns ideas into" — replaced with "lets you generate X from Y
           using Z").
       (c) Must include a clearly visible link to the privacy policy. -->
  <noscript>
    <div style="max-width:780px;margin:48px auto;padding:24px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.6;color:#111">
      <h1 style="margin:0 0 8px;font-size:32px">Flik AI</h1>
      <p style="margin:0 0 16px;font-size:20px;color:#555">The Creative Agent for AI Video, Image &amp; Audio</p>
      <p style="margin:0 0 16px;font-size:18px">
        <strong>Flik AI</strong> lets you generate videos, images, audio voiceovers, and music from text prompts using
        frontier AI models. Enter a description and Flik AI produces the media for you with Veo 3.1, Kling 3.0 Pro,
        Seedance 2.0, Seedream 4.5, Nano Banana Pro, ElevenLabs 3.0, and Suno 5.0 &mdash; all in one workspace.
      </p>
      <h2 style="margin:24px 0 8px;font-size:20px">Sign in with your Google Account</h2>
      <p>
        Flik AI uses Sign in with Google for authentication. When you sign in, we request access to your Google
        profile (<em>openid</em>, <em>profile</em>, <em>email</em> scopes) in order to:
      </p>
      <ul>
        <li>Identify your account using your Google email address.</li>
        <li>Display your name and profile picture inside the app.</li>
        <li>Save your generated projects to your account so you can access them on any device.</li>
      </ul>
      <p>
        Flik AI does <strong>not</strong> request access to your Google Drive, Gmail, Calendar, Contacts, or any
        other sensitive Google user data. We never use your data to train AI models. See our
        <a href="/privacy-policy">Privacy Policy</a> for full details on how we handle your information, and our
        <a href="/terms">Terms of Service</a> for the terms under which Flik AI is provided.
      </p>
      <h2 style="margin:24px 0 8px;font-size:20px">What you can make with Flik AI</h2>
      <ul>
        <li>Generate AI videos from text prompts (Veo 3.1, Kling 3.0 Pro, Seedance 2.0, Hailuo 2.3).</li>
        <li>Generate AI images and edits (Seedream 4.5, Nano Banana Pro, Nano Banana 2).</li>
        <li>Generate AI voiceovers and narration (ElevenLabs 3.0).</li>
        <li>Generate AI music and soundtracks (Suno 5.0).</li>
        <li>Organize projects, iterate on prompts, and export finished media.</li>
      </ul>
      <h2 style="margin:24px 0 8px;font-size:20px">Get started</h2>
      <p>
        Visit <a href="https://www.flikai.com/">https://www.flikai.com/</a> in a modern browser with JavaScript
        enabled to launch the Flik AI app and sign in with Google.
      </p>
      <h2 style="margin:24px 0 8px;font-size:20px">Legal &amp; contact</h2>
      <ul>
        <li><a href="/privacy-policy">Privacy Policy</a></li>
        <li><a href="/terms">Terms of Service</a></li>
        <li><a href="/cookies">Cookie Policy</a></li>
        <li><a href="/pricing">Pricing</a></li>
        <li>Contact: <a href="mailto:support@flikai.com">support@flikai.com</a></li>
      </ul>
      <p style="margin-top:24px;color:#555;font-size:14px">
        &copy; Flik AI. All rights reserved.
      </p>
    </div>
  </noscript>
  <!-- <script
      crossOrigin="anonymous"
      src="//unpkg.com/react-scan/dist/auto.global.js"
    ></script> -->
</body>

</html>