
#!/usr/bin/env python3
"""
sync-assets.py - Copia os assets gerados no Flik (/Assets/...) para public/ do Next.js.

Uso:
    python scripts/sync-assets.py [--source PATH]

Por padrão, busca os assets em ../../Assets/ relativo a este script (estrutura do projeto Flik).
Se rodar fora do Flik, passe --source com o caminho da pasta /Assets local.

Faz:
    /Assets/Mascot/*.jpg       → public/mascot/
    /Assets/Shop/*.jpg         → public/shop/
    /Assets/Screens/*.jpg      → public/screens/
    /Assets/Animations/*.mp4   → public/animations/
    /Assets/Brand/*.jpg        → public/brand/
"""

from __future__ import annotations
import argparse
import shutil
import sys
from pathlib import Path

MAPPINGS = {
    "Mascot": "mascot",
    "Shop": "shop",
    "Screens": "screens",
    "Animations": "animations",
    "Brand": "brand",
}


def copy_folder(src: Path, dst: Path) -> tuple[int, int]:
    """Copy all files from src to dst. Returns (copied, skipped)."""
    if not src.exists():
        print(f"  ⚠️  Origem não existe: {src}")
        return (0, 0)

    dst.mkdir(parents=True, exist_ok=True)

    copied = 0
    skipped = 0
    for item in sorted(src.iterdir()):
        if not item.is_file():
            continue
        target = dst / item.name
        if target.exists() and target.stat().st_mtime >= item.stat().st_mtime:
            skipped += 1
            continue
        shutil.copy2(item, target)
        size_kb = item.stat().st_size / 1024
        print(f"  ✅ {item.name}  ({size_kb:.0f} KB)")
        copied += 1

    return (copied, skipped)


def main() -> int:
    parser = argparse.ArgumentParser(description="Sincroniza assets do Flik para public/")
    parser.add_argument(
        "--source",
        type=Path,
        default=None,
        help="Caminho da pasta /Assets (default: tenta ../../Assets relativo ao script)",
    )
    parser.add_argument(
        "--public",
        type=Path,
        default=None,
        help="Caminho da pasta public/ (default: ../public relativo ao script)",
    )
    args = parser.parse_args()

    script_dir = Path(__file__).parent.resolve()
    project_root = script_dir.parent  # Code/projeto-delta/

    source_root = args.source or (project_root.parent.parent / "Assets")
    public_root = args.public or (project_root / "public")

    print(f"📦 Sincronizando assets")
    print(f"   Origem: {source_root}")
    print(f"   Destino: {public_root}")
    print()

    if not source_root.exists():
        print(f"❌ Pasta de origem não encontrada: {source_root}")
        print(f"   Use --source <caminho> para apontar para sua pasta /Assets")
        return 1

    total_copied = 0
    total_skipped = 0

    for src_name, dst_name in MAPPINGS.items():
        src = source_root / src_name
        dst = public_root / dst_name
        print(f"📂 {src_name}/ → public/{dst_name}/")
        copied, skipped = copy_folder(src, dst)
        total_copied += copied
        total_skipped += skipped
        if copied == 0 and skipped == 0:
            print(f"  (nenhum arquivo)")
        print()

    print(f"✅ Concluído. {total_copied} novos · {total_skipped} já atualizados.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
