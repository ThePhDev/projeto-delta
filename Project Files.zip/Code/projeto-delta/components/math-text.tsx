
"use client";

import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";

/**
 * Renderiza texto com markdown + LaTeX inline ($...$) e bloco ($$...$$).
 * Usado em resoluções de questões que vêm do banco com fórmulas matemáticas.
 */
export function MathText({ children, className }: { children: string; className?: string }) {
  return (
    <div className={`prose prose-sm max-w-none prose-p:my-2 prose-strong:text-delta-graphite ${className ?? ""}`}>
      <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
        {children}
      </ReactMarkdown>
    </div>
  );
}
